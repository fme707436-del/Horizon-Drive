HORIZON DRIVE — REALISTIC EDITION V5
====================================

สิ่งที่เพิ่มใน V5
- เมนูหลักแนว premium racing game
- โลก 3D ขนาดใหญ่: เมือง + ชายฝั่ง + ภูเขา
- ถนนหลายเส้น + lane markings + street lights
- รถจราจร 34 คัน
- ระบบกลางวัน/กลางคืน
- ฝน
- ถนน/วัสดุรถแบบ metallic และ glass
- Garage / Car Shop / ซื้อรถ / Credits / Save
- Nitro, Gear, RPM, Speed HUD
- Race 10 Checkpoints + reward
- Web Audio เครื่องยนต์แบบเบา ๆ
- รองรับโมเดลรถ GLB/GLTF จากภายนอก
- Responsive UI

วิธีเปิด
1) แตก ZIP
2) เปิดโฟลเดอร์ด้วย VS Code
3) ติดตั้งส่วนเสริม "Live Server"
4) คลิกขวา index.html -> Open with Live Server
5) เล่นด้วย WASD หรือปุ่มลูกศร

ใส่โมเดลรถจริง
- ใส่ไฟล์ .glb ที่มีสิทธิ์ใช้งานใน assets/cars/
- เปิด game.js
- แก้ MODEL_PATHS เช่น
  APEX_R: "assets/cars/my-car.glb"
- ถ้าโมเดลโหลดไม่ได้ เกมจะใช้รถ procedural สำรองแทน

หมายเหตุเรื่องโมเดลจากเว็บ
ต้องตรวจ license ของแต่ละโมเดลก่อนนำมาแจก/ฝังใน ZIP โดยเฉพาะโมเดลจาก marketplace หรือ Sketchfab
อย่า hotlink ไฟล์ที่ไม่มีสิทธิ์

ข้อจำกัดของ V5
- ยังเป็นเกม WebGL prototype ไม่ใช่เกม AAA
- ฟิสิกส์ยังเป็น arcade/procedural
- ไม่มีระบบ multiplayer
- โมเดลภายนอกยังไม่ได้ฝังมาให้ เพราะสิทธิ์การแจกจ่ายของแต่ละโมเดลต่างกัน
