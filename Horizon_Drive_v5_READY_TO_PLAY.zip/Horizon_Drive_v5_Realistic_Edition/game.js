import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/loaders/GLTFLoader.js";

const $=id=>document.getElementById(id);
const CARS=[
{id:"APEX_R",name:"APEX R",desc:"Supercar สำหรับเริ่มต้น",price:0,top:315,acc:12,grip:90,nitro:100,color:"#d9dde3"},
{id:"VOLT_GT",name:"VOLT GT",desc:"Grand Tourer สมดุลและเร็ว",price:18000,top:285,acc:10,grip:98,nitro:95,color:"#3ab9e9"},
{id:"NOVA_X",name:"NOVA X",desc:"Hypercar น้ำหนักเบา",price:42000,top:335,acc:14,grip:82,nitro:100,color:"#9b82ff"},
{id:"PHANTOM_RS",name:"PHANTOM RS",desc:"Track-focused beast",price:75000,top:350,acc:15,grip:100,nitro:100,color:"#f2f3f5"}
];
const MODEL_PATHS={APEX_R:null,VOLT_GT:null,NOVA_X:null,PHANTOM_RS:null}; // ใส่ path .glb ได้
let save=JSON.parse(localStorage.getItem("hd_v5_save")||'{"money":25000,"owned":["APEX_R"],"car":"APEX_R","paint":"#d9dde3"}');
let current=CARS.find(c=>c.id===save.car)||CARS[0];
let scene,camera,renderer,clock,player,world,traffic=[],rain,roadMat,roadWet=true;
let speed=0,heading=0,nitro=100,keys={},distance=0,race=false,raceTime=0,raceIndex=0,checkpoints=[],eventShown=false;
let day=0.35,audioCtx=null,engineOsc=null;
const loader=new GLTFLoader();

function mat(c,r=.75,m=.05){return new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m})}
function meshBox(x,y,z,c,r=.75,m=.05){let m1=new THREE.Mesh(new THREE.BoxGeometry(x,y,z),mat(c,r,m));m1.castShadow=m1.receiveShadow=true;return m1}
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1800)}

async function init(){
  bind(); setup(); buildPlayer(); buildTraffic(); buildRain(); populateShop(); updateGarage();
  for(let i=0;i<=100;i+=5){$("loadBar").style.width=i+"%";await new Promise(r=>setTimeout(r,8))}
  $("loading").style.display="none";animate();
}
function setup(){
 scene=new THREE.Scene();scene.background=new THREE.Color(0x6f879d);scene.fog=new THREE.FogExp2(0x77889a,.00055);
 camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,5000);
 renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 document.body.appendChild(renderer.domElement);clock=new THREE.Clock();
 const hemi=new THREE.HemisphereLight(0xcbdcff,0x172027,1.35);scene.add(hemi);
 const sun=new THREE.DirectionalLight(0xffffff,2.8);sun.position.set(500,900,250);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-900;sun.shadow.camera.right=900;sun.shadow.camera.top=900;sun.shadow.camera.bottom=-900;scene.add(sun);
 world=new THREE.Group();scene.add(world);
 addGround();addRoads();addCity();addMountains();addCoast();addStreetLights();
}
function addGround(){
 let g=new THREE.Mesh(new THREE.PlaneGeometry(5000,5000),mat(0x26332b,.98));g.rotation.x=-Math.PI/2;g.receiveShadow=true;world.add(g);
}
function addRoads(){
 const asphalt=mat(0x151a20,.92,.03);
 for(let x=-900;x<=900;x+=300){let r=meshBox(66,.12,2200,0x151a20,.95);r.position.set(x,.05,0);world.add(r);for(const s of[-1,1]){let l=meshBox(2,.14,2200,0xe5d8a6,.55);l.position.set(x+s*28,.13,0);world.add(l)}}
 for(let z=-900;z<=900;z+=300){let r=meshBox(2200,.12,66,0x151a20,.95);r.position.set(0,.05,z);world.add(r)}
 // lane markings
 const mark=mat(0xdce2e7,.7);
 for(let x=-900;x<=900;x+=300)for(let z=-1000;z<1000;z+=36){let q=meshBox(1,.15,14,0xdce2e7,.7);q.position.set(x,.14,z);world.add(q)}
 for(let z=-900;z<=900;z+=300)for(let x=-1000;x<1000;x+=36){let q=meshBox(14,.15,1,0xdce2e7,.7);q.position.set(x,.14,z);world.add(q)}
}
function addCity(){
 for(let x=-830;x<=830;x+=70)for(let z=-830;z<=830;z+=70){
  if(Math.abs(x%300)<80||Math.abs(z%300)<80)continue;
  const h=12+Math.random()*95,w=35+Math.random()*18;
  let b=meshBox(w,h,w*.9,new THREE.Color().setHSL(.6,.08,.22+Math.random()*.16),.82,.1);b.position.set(x,h/2,z);world.add(b);
  if(Math.random()>.25){let roof=meshBox(w*.72,1.4,w*.72,0x171c23,.6,.2);roof.position.set(x,h+1,z);world.add(roof)}
  if(Math.random()>.45){let glow=meshBox(w*.65,.15,w*.65,0xbcc9d9,.2,.5);glow.position.set(x,h+.2,z);world.add(glow)}
 }
}
function addMountains(){
 for(let i=0;i<28;i++){let a=Math.random()*Math.PI*2,d=1350+Math.random()*550,h=180+Math.random()*300;let m=new THREE.Mesh(new THREE.ConeGeometry(180+Math.random()*130,h,7),mat(0x29353b,1,0));m.position.set(Math.cos(a)*d,h/2,Math.sin(a)*d);world.add(m)}
}
function addCoast(){
 const water=new THREE.Mesh(new THREE.PlaneGeometry(2200,850),new THREE.MeshStandardMaterial({color:0x164a68,roughness:.15,metalness:.35}));water.rotation.x=-Math.PI/2;water.position.set(0,-.01,-1450);world.add(water);
 for(let x=-1000;x<=1000;x+=25){let rock=meshBox(20,2+Math.random()*3,14,0x66706f,1);rock.position.set(x,.8,-1020+Math.sin(x*.02)*35);world.add(rock)}
}
function addStreetLights(){
 for(let x=-870;x<=870;x+=60)for(let z=-930;z<=930;z+=120){if(Math.abs(x%300)>35)continue;let pole=meshBox(.25,9,.25,0x252a31,.4,.5);pole.position.set(x+34,4.5,z);world.add(pole);let lamp=new THREE.PointLight(0xe7f1ff,.7,35);lamp.position.set(x+34,9,z);world.add(lamp)}
}
function carMesh(color,scale=1){
 const g=new THREE.Group();g.scale.setScalar(scale);
 const body=new THREE.Mesh(new THREE.BoxGeometry(2.2,.55,4.5),new THREE.MeshStandardMaterial({color,roughness:.22,metalness:.75}));body.position.y=.75;body.castShadow=true;g.add(body);
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.72,.58,1.9),new THREE.MeshStandardMaterial({color:0x0d141b,roughness:.12,metalness:.65,transparent:true,opacity:.9}));cabin.position.set(0,1.18,-.15);cabin.rotation.x=-.05;g.add(cabin);
 const glass=meshBox(1.82,.08,1.5,0x99a8b7,.08,.8);glass.position.set(0,1.37,-.16);g.add(glass);
 for(const sx of[-1,1])for(const sz of[-1,1]){let w=new THREE.Mesh(new THREE.CylinderGeometry(.4,.4,.28,18),mat(0x050608,.8,.05));w.rotation.z=Math.PI/2;w.position.set(sx*1.08,.45,sz*1.4);w.castShadow=true;g.add(w)}
 const head=meshBox(.34,.18,.06,0xeaf6ff,.1,.7);head.position.set(-.7,.82,2.25);g.add(head);const head2=head.clone();head2.position.x=.7;g.add(head2);
 return g;
}
async function loadExternal(def,parent){
 const path=MODEL_PATHS[def.id];if(!path)return false;
 return new Promise(resolve=>loader.load(path,g=>{
   const m=g.scene;const b=new THREE.Box3().setFromObject(m),s=b.getSize(new THREE.Vector3());const scale=4.2/Math.max(s.x,s.z);m.scale.setScalar(scale);b.setFromObject(m);m.position.sub(b.getCenter(new THREE.Vector3()));m.position.y+=.5;m.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});parent.add(m);resolve(true)},undefined,()=>resolve(false)));
}
function buildPlayer(){
 player=new THREE.Group();player.position.set(0,.2,120);world.add(player);const fallback=carMesh(save.paint||current.color);player.add(fallback);
 loadExternal(current,player).then(ok=>{if(ok){fallback.visible=false;player.userData.external=true}});
}
function rebuildPlayer(){world.remove(player);buildPlayer()}
function buildTraffic(){
 const cols=[0xf1f3f5,0x2e8bd6,0xe2a12a,0x8c67d6,0x383e47];
 for(let i=0;i<34;i++){let t=carMesh(cols[i%cols.length],.72);t.position.set((i%2?1:-1)*(Math.floor(i/2)%4)*300+(i%2?30:-30),.1,(i*157)%2100-1050);t.userData.axis=i%2?"x":"z";t.userData.v=25+Math.random()*55;world.add(t);traffic.push(t)}
}
function buildRain(){
 const pos=[];for(let i=0;i<2200;i++)pos.push((Math.random()-.5)*2300,Math.random()*500,(Math.random()-.5)*2300);
 const geo=new THREE.BufferGeometry();geo.setAttribute("position",new THREE.Float32BufferAttribute(pos,3));
 rain=new THREE.Points(geo,new THREE.PointsMaterial({color:0xb9d7f2,size:.9,transparent:true,opacity:.5}));rain.visible=false;world.add(rain);
}
function bind(){
 $("playBtn").onclick=()=>{show("hud");startAudio();toast("เริ่มการขับขี่ — ถนนเปิดรอคุณอยู่")};
 $("garageBtn").onclick=()=>show("garage");$("shopBtn").onclick=()=>show("shop");$("settingsBtn").onclick=()=>show("settings");$("mapBtn").onclick=()=>toast("WORLD MAP: เปิดใช้งานในโลกจริงระหว่างขับ");
 document.querySelectorAll(".back").forEach(b=>b.onclick=()=>show("menu"));
 $("pauseBtn").onclick=()=>pause(true);$("resumeBtn").onclick=()=>pause(false);$("quitBtn").onclick=()=>{pause(false);show("menu")};
 $("startRace").onclick=startRace;$("cancelRace").onclick=()=>$("eventModal").classList.remove("show");$("resultClose").onclick=()=>$("result").classList.remove("show");
 $("applyPaint").onclick=()=>{save.paint=$("paint").value;saveNow();rebuildPlayer();updateMenuCar();toast("เปลี่ยนสีรถแล้ว")};
 $("volume").oninput=e=>{window.gameVolume=+e.target.value;if(engineOsc)engineOsc.gain.value=0.02*window.gameVolume};
 $("time").oninput=e=>day=+e.target.value;
 $("rain").onchange=e=>rain.visible=e.target.checked;
 $("wetRoad").onchange=e=>roadWet=e.target.checked;
 $("resetSave").onclick=()=>{localStorage.removeItem("hd_v5_save");location.reload()};
 addEventListener("keydown",e=>{keys[e.code]=true;if(e.code==="Escape")pause(!$("pause").classList.contains("show"));if(e.code==="KeyR")resetCar()});
 addEventListener("keyup",e=>keys[e.code]=false);addEventListener("resize",resize);
}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");if(id==="shop")populateShop();if(id==="garage")updateGarage();updateMenuCar()}
function pause(v){$("pause").classList.toggle("show",v)}
function saveNow(){localStorage.setItem("hd_v5_save",JSON.stringify(save))}
function updateMenuCar(){$("menuCar").textContent=current.name}
function populateShop(){
 $("shopMoney").textContent="CREDITS "+save.money.toLocaleString();$("shopList").innerHTML="";
 CARS.forEach(c=>{let d=document.createElement("div");d.className="car-card";d.innerHTML=`<div class="thumb"></div><h3>${c.name}</h3><p>${c.desc}</p><b>${c.price?c.price.toLocaleString()+" CR":"STARTER"}</b><button>${save.owned.includes(c.id)?"SELECT":"BUY"}</button>`;
 d.querySelector("button").onclick=()=>{if(save.owned.includes(c.id)){save.car=c.id;current=c;save.paint=c.color;saveNow();updateGarage();rebuildPlayer();toast(c.name+" SELECTED")}else if(save.money>=c.price){save.money-=c.price;save.owned.push(c.id);save.car=c.id;current=c;save.paint=c.color;saveNow();populateShop();updateGarage();rebuildPlayer();toast("ซื้อ "+c.name+" สำเร็จ")}else toast("Credits ไม่พอ")};$("shopList").appendChild(d)})
}
function updateGarage(){
 $("garageMoney").textContent="CREDITS "+save.money.toLocaleString();$("carName").textContent=current.name;$("carDesc").textContent=current.desc;$("paint").value=save.paint||current.color;
 $("carStats").innerHTML=[["TOP",current.top/3.5],["ACC",current.acc*7],["GRIP",current.grip],["NITRO",current.nitro]].map(a=>`<div class="stat"><b>${a[0]}</b><i><b style="width:${Math.min(100,a[1])}%"></b></i></div>`).join("")
}
function startRace(){
 $("eventModal").classList.remove("show");race=true;raceTime=0;raceIndex=0;distance=0;eventShown=true;checkpoints.forEach(x=>world.remove(x));checkpoints=[];
 for(let i=0;i<10;i++){let cp=new THREE.Mesh(new THREE.TorusGeometry(10,1,10,36),new THREE.MeshBasicMaterial({color:0xe8edf4}));cp.rotation.x=Math.PI/2;cp.position.set(Math.sin(i*.9)*480,9,300-i*170);world.add(cp);checkpoints.push(cp)}
 $("eventStatus").textContent="RACE";$("objective").textContent="CHECKPOINT 1/10";toast("COASTLINE SPRINT — GO!")
}
function finishRace(){
 race=false;let reward=8000+Math.max(0,Math.round(12000-raceTime*140));save.money+=reward;saveNow();checkpoints.forEach(x=>world.remove(x));checkpoints=[];
 $("resultText").innerHTML=`เวลา <b>${raceTime.toFixed(2)}s</b><br>รางวัล <b>+${reward.toLocaleString()} CR</b>`;$("result").classList.add("show");$("eventStatus").textContent="FREE ROAM";$("objective").textContent="สำรวจเมืองเพื่อค้นหาอีเวนต์"
}
function resetCar(){player.position.set(0,.2,120);speed=0;heading=0;player.rotation.y=0;toast("รถถูกรีเซ็ต")}
function drive(dt){
 const f=keys.KeyW||keys.ArrowUp,b=keys.KeyS||keys.ArrowDown,l=keys.KeyA||keys.ArrowLeft,r=keys.KeyD||keys.ArrowRight,boost=keys.ShiftLeft||keys.ShiftRight,hand=keys.Space;
 const max=current.top/3.6;
 if(f)speed+=current.acc*dt;if(b)speed-=current.acc*1.35*dt;if(!f&&!b)speed*=Math.pow(.984,dt*60);
 if(boost&&nitro>0&&speed>4){speed+=24*dt;nitro-=30*dt}else nitro=Math.min(100,nitro+7*dt);
 speed=THREE.MathUtils.clamp(speed,-18,max+(boost?30:0));
 const steer=(l?-1:r?1:0);heading+=steer*dt*(speed>=0?1:-1)*(0.8+Math.min(Math.abs(speed)/max,.8))*(hand?1.7:1);
 player.rotation.y=heading;const dir=new THREE.Vector3(Math.sin(heading),0,Math.cos(heading));player.position.addScaledVector(dir,speed*dt);
 player.position.x=THREE.MathUtils.clamp(player.position.x,-1080,1080);player.position.z=THREE.MathUtils.clamp(player.position.z,-1080,1080);
 distance+=Math.abs(speed*dt);raceTime+=race?dt:0;
 if(race&&checkpoints[raceIndex]&&player.position.distanceTo(checkpoints[raceIndex].position)<22){raceIndex++;if(raceIndex>=10)finishRace();else $("objective").textContent=`CHECKPOINT ${raceIndex+1}/10`}
 if(!race&&!eventShown&&distance>1100){eventShown=true;$("eventModal").classList.add("show")}
 $("speed").textContent=String(Math.max(0,Math.round(Math.abs(speed)*3.6))).padStart(3,"0");$("nitroBar").style.width=nitro+"%";$("nitroText").textContent=Math.round(nitro)+"%";$("gear").textContent=Math.abs(speed)<2?"N":Math.min(6,Math.max(1,Math.ceil(Math.abs(speed)/max*6)));
 $("rpm").textContent="▮".repeat(Math.min(10,Math.max(1,Math.round(Math.abs(speed)/max*10))))+"·".repeat(10-Math.min(10,Math.round(Math.abs(speed)/max*10)));
 if(engineOsc)engineOsc.frequency.value=70+Math.abs(speed)*5;
}
function updateEnvironment(){
 const sunAngle=day*Math.PI*2-Math.PI/2,light=(Math.sin(sunAngle)+1)/2;
 scene.background.setHSL(.59,.24,.12+.48*light);scene.fog.color.copy(scene.background);scene.fog.density=.00042+.00025*(1-light);
 if(rain)rain.rotation.y+=.0008;
}
function startAudio(){
 if(audioCtx)return;audioCtx=new (window.AudioContext||window.webkitAudioContext)();engineOsc=audioCtx.createOscillator();const gain=audioCtx.createGain();engineOsc.type="sawtooth";engineOsc.frequency.value=70;gain.gain.value=.015;engineOsc.connect(gain).connect(audioCtx.destination);engineOsc.start()
}
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(.033,clock.getDelta());
 if($("hud").classList.contains("active")&&!$("pause").classList.contains("show"))drive(dt);
 updateEnvironment();
 for(const t of traffic){if(t.userData.axis==="x")t.position.x+=t.userData.v*dt;else t.position.z+=t.userData.v*dt;if(t.position.x>1120)t.position.x=-1120;if(t.position.x<-1120)t.position.x=1120;if(t.position.z>1120)t.position.z=-1120;if(t.position.z<-1120)t.position.z=1120}
 const target=player.position.clone();const back=new THREE.Vector3(-Math.sin(heading)*13,6.5,-Math.cos(heading)*13);camera.position.lerp(target.clone().add(back),.075);camera.lookAt(target.clone().add(new THREE.Vector3(0,1.0,5)));
 renderer.render(scene,camera)
}
function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}
init();
